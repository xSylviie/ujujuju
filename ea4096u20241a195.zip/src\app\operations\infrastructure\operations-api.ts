import { Injectable } from '@angular/core';
import { BaseApi } from '../../shared/infrastructure/base-api';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Rental } from '../domain/model/rental.entity';
import { Incident } from '../domain/model/incident.entity';
import { RentalsApiEndpoint } from './rentals-api-endpoint';
import { IncidentsApiEndpoint } from './incidents-api-endpoint';

/**
 * @summary Infrastructure facade exposing Operations bounded-context endpoint operations.
 * @author u20241a195 - Sofia Diaz Yurivilca
 */
@Injectable({ providedIn: 'root' })
export class OperationsApi extends BaseApi {
  private readonly rentalsEndpoint: RentalsApiEndpoint;
  private readonly incidentsEndpoint: IncidentsApiEndpoint;

  constructor(http: HttpClient) {
    super();
    this.rentalsEndpoint = new RentalsApiEndpoint(http);
    this.incidentsEndpoint = new IncidentsApiEndpoint(http);
  }

  getRentals(): Observable<Rental[]> {
    return this.rentalsEndpoint.getAll();
  }

  createRental(rental: Rental): Observable<Rental> {
    return this.rentalsEndpoint.create(rental);
  }

  getIncidents(): Observable<Incident[]> {
    return this.incidentsEndpoint.getAll();
  }

  createIncident(incident: Incident): Observable<Incident> {
    return this.incidentsEndpoint.create(incident);
  }
}
