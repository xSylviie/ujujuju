/**
 * @summary Development environment configuration.
 * @author u20241a195 - Sofia Diaz Yurivilca
 */
export const environment = {
  production: false,
  serverBasePath: 'http://localhost:3000',
  logoProviderApiBaseUrl: 'https://logo.clearbit.com',
};
