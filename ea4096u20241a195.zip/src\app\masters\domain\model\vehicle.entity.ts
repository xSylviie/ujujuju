import { BaseEntity } from '../../../shared/domain/model/base-entity';

/**
 * @summary Domain entity representing a vehicle in the fleet.
 * @author u20241a195 - Sofia Diaz Yurivilca
 */
export interface Vehicle extends BaseEntity {
  id: number;
  make: string;
  model: string;
  mileageKm: number;
  dailyRate: number;
  vehicleType: 'ECONOMY' | 'SUV' | 'LUXURY';
  status: 'AVAILABLE' | 'RENTED' | 'MAINTENANCE';
}
