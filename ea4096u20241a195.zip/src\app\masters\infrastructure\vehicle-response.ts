import { BaseResource, BaseResponse } from '../../shared/infrastructure/base-response';

/**
 * @summary Infrastructure resource contract representing a vehicle record.
 * @author u20241a195 - Sofia Diaz Yurivilca
 */
export interface VehicleResource extends BaseResource {
  id: number;
  make: string;
  model: string;
  mileageKm: number;
  dailyRate: number;
  vehicleType: string;
  status: string;
}

/**
 * @summary Infrastructure response envelope for vehicle collection queries.
 * @author u20241a195 - Sofia Diaz Yurivilca
 */
export interface VehiclesResponse extends BaseResponse {
  vehicles: VehicleResource[];
}
