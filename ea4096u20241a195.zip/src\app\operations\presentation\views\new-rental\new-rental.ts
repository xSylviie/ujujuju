import { Component, inject, signal } from '@angular/core';
import { Router } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { TranslatePipe } from '@ngx-translate/core';
import { OperationsStore } from '../../../application/operation.store';
import { MastersStore } from '../../../../masters/application/masters.store';
import { Rental } from '../../../domain/model/rental.entity';

/**
 * @summary View for creating a new vehicle rental contract.
 * @author u20241a195 - Sofia Diaz Yurivilca
 */
@Component({
  selector: 'app-new-rental',
  standalone: true,
  imports: [
    FormsModule,
    MatFormFieldModule,
    MatInputModule,
    MatButtonModule,
    MatSnackBarModule,
    TranslatePipe,
  ],
  templateUrl: './new-rental.html',
  styleUrl: './new-rental.css',
})
export class NewRental {
  private readonly router = inject(Router);
  private readonly operationsStore = inject(OperationsStore);
  private readonly mastersStore = inject(MastersStore);
  private readonly snackBar = inject(MatSnackBar);

  protected vehicleId: number | null = null;
  protected clientId: number | null = null;
  protected durationDays: number | null = null;
  protected isSubmitting = signal<boolean>(false);

  protected onCreate(): void {
    if (!this.vehicleId || !this.clientId || !this.durationDays) {
      this.snackBar.open('Please fill all required fields.', 'Close', { duration: 3000 });
      return;
    }

    if (this.durationDays < 1) {
      this.snackBar.open('Duration must be at least 1 day.', 'Close', { duration: 3000 });
      return;
    }

    const vehicle = this.mastersStore.getVehicleById(this.vehicleId);
    if (!vehicle) {
      this.snackBar.open('Vehicle not found. Please check the Vehicle ID.', 'Close', {
        duration: 3000,
      });
      return;
    }

    if (this.operationsStore.hasActiveRental(this.vehicleId)) {
      this.snackBar.open('This vehicle already has an active rental.', 'Close', { duration: 4000 });
      return;
    }

    const startDate = new Date();
    const endDate = new Date(startDate);
    endDate.setDate(endDate.getDate() + this.durationDays);

    const rental: Rental = {
      id: 0,
      vehicleId: this.vehicleId,
      clientId: this.clientId,
      startDate: startDate.toISOString(),
      endDate: endDate.toISOString(),
      durationDays: this.durationDays,
      totalCost: this.durationDays * vehicle.dailyRate,
      status: 'ACTIVE',
    };

    this.isSubmitting.set(true);
    this.operationsStore
      .createRentalWithIncident(rental)
      .then(() => {
        this.isSubmitting.set(false);
        this.snackBar.open('Rental created successfully!', 'Close', { duration: 2000 });
        this.router.navigate(['/home']);
      })
      .catch(() => {
        this.isSubmitting.set(false);
        this.snackBar.open('Error creating rental. Please try again.', 'Close', { duration: 3000 });
      });
  }

  protected onCancel(): void {
    this.router.navigate(['/home']);
  }
}
