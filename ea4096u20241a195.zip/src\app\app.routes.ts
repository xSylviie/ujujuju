import { Routes } from '@angular/router';
import { Home } from './masters/presentation/views/home/home';

const pageNotFound = () =>
  import('./shared/presentation/views/page-not-found/page-not-found').then((m) => m.PageNotFound);

const operationsRoutes = () =>
  import('./operations/presentation/operation.routes').then((m) => m.operationsRoutes);

const baseTitle = 'Enterprise Fleet Manager';

/**
 * @summary Root route configuration composing all bounded-context routes.
 * @author u20241a195 - Sofia Diaz Yurivilca
 */
export const routes: Routes = [
  { path: 'home', component: Home, title: `${baseTitle} - Home` },
  { path: 'operations', loadChildren: operationsRoutes },
  { path: '', redirectTo: '/home', pathMatch: 'full' },
  { path: '**', loadComponent: pageNotFound, title: `${baseTitle} - Page Not Found` },
];
