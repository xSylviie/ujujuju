import { VehicleResource, VehiclesResponse } from './vehicle-response';
import { Vehicle } from '../domain/model/vehicle.entity';
import { BaseAssembler } from '../../shared/infrastructure/base-assembler';

/**
 * @summary Maps vehicle domain entities to and from infrastructure contracts.
 * @author u20241a195 - Sofia Diaz Yurivilca
 */
export class VehicleAssembler implements BaseAssembler<Vehicle, VehicleResource, VehiclesResponse> {
  toEntitiesFromResponse(response: VehiclesResponse): Vehicle[] {
    return response.vehicles.map((r) => this.toEntityFromResource(r));
  }

  toEntityFromResource(resource: VehicleResource): Vehicle {
    return {
      id: resource.id,
      make: resource.make,
      model: resource.model,
      mileageKm: resource.mileageKm,
      dailyRate: resource.dailyRate,
      vehicleType: resource.vehicleType as Vehicle['vehicleType'],
      status: resource.status as Vehicle['status'],
    };
  }

  toResourceFromEntity(entity: Vehicle): VehicleResource {
    return {
      id: entity.id,
      make: entity.make,
      model: entity.model,
      mileageKm: entity.mileageKm,
      dailyRate: entity.dailyRate,
      vehicleType: entity.vehicleType,
      status: entity.status,
    };
  }
}
