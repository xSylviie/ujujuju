/**
 * @summary Production environment configuration.
 * @author u20241a195 - Sofia Diaz Yurivilca
 */
export const environment = {
  production: true,
  serverBasePath: 'http://localhost:3000',
  logoProviderApiBaseUrl: 'https://logo.clearbit.com',
  enterpriseDomain: 'enterprise.com',
  fallbackLogoPath: '/images/enterprise-logo.svg',
};
