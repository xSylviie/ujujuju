import { BaseEntity } from '../../../shared/domain/model/base-entity';

/**
 * @summary Domain entity representing an incident associated with a vehicle or rental.
 * @author u20241a195 - Sofia Diaz Yurivilca
 */
export interface Incident extends BaseEntity {
  id: number;
  vehicleId: number;
  rentalId: number | null;
  incidentType: 'DAMAGE' | 'BREAKDOWN' | 'CLEANING' | 'REPAIR';
  registeredAt: string;
  estimatedRepairCost: number;
  priority: 'HIGH' | 'NORMAL';
}
