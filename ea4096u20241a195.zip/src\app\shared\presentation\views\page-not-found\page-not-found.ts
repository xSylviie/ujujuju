import { Component, inject, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { MatButtonModule } from '@angular/material/button';
import { TranslatePipe } from '@ngx-translate/core';

/**
 * @summary Displays fallback content for unknown routes, showing the invalid path.
 * @author u20241a195 - Sofia Diaz Yurivilca
 */
@Component({
  selector: 'app-page-not-found',
  standalone: true,
  imports: [MatButtonModule, TranslatePipe],
  templateUrl: './page-not-found.html',
  styleUrl: './page-not-found.css',
})
export class PageNotFound implements OnInit {
  protected invalidPath: string = '';
  private route: ActivatedRoute = inject(ActivatedRoute);
  private router: Router = inject(Router);

  ngOnInit(): void {
    this.invalidPath = this.router.url;
  }

  protected navigateToHome(): void {
    this.router.navigate(['/home']).then();
  }
}
