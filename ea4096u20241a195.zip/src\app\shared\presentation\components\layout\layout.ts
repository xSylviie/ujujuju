import { Component, signal } from '@angular/core';
import { RouterLink, RouterLinkActive, RouterOutlet } from '@angular/router';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatButtonModule } from '@angular/material/button';
import { TranslatePipe } from '@ngx-translate/core';
import { LanguageSwitcher } from '../language-switcher/language-switcher';
import { environment } from '../../../../../environments/environment';

/**
 * @summary Main shell component that hosts top-level navigation and routed content.
 * @author  u20241a195 - Sofia Diaz Yurivilca
 */
@Component({
  selector: 'app-layout',
  standalone: true,
  imports: [
    RouterOutlet,
    RouterLink,
    RouterLinkActive,
    MatToolbarModule,
    MatButtonModule,
    TranslatePipe,
    LanguageSwitcher,
  ],
  templateUrl: './layout.html',
  styleUrl: './layout.css',
})
export class Layout {
  protected readonly logoUrl = `${environment.logoProviderApiBaseUrl}/${environment.enterpriseDomain}`;
  protected readonly fallbackLogoUrl = environment.fallbackLogoPath;

  protected readonly options = signal([
    { link: '/home', label: 'option.home' },
    { link: '/operations/rentals/new', label: 'option.newRental' },
  ]);

  /** Falls back to the bundled Enterprise logo when Clearbit is unavailable. */
  protected onLogoError(event: Event): void {
    const img = event.target as HTMLImageElement;
    if (img.src !== this.fallbackLogoUrl) {
      img.src = this.fallbackLogoUrl;
    }
  }
}
