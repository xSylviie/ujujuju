import { Component, Input } from '@angular/core';
import { MatCardModule } from '@angular/material/card';
import { TranslatePipe } from '@ngx-translate/core';
import { CurrencyPipe } from '@angular/common';

/**
 * @summary Card component displaying statistical metrics for a specific vehicle type.
 * @author u20241a195 - Sofia Diaz Yurivilca
 */
@Component({
  selector: 'app-vehicle-type-stats',
  standalone: true,
  imports: [MatCardModule, TranslatePipe, CurrencyPipe],
  templateUrl: './vehicle-type-stats.html',
  styleUrl: './vehicle-type-stats.css',
})
export class VehicleTypeStats {
  @Input() vehicleType: string = '';
  @Input() dailyRevenuePotential: number = 0;
  @Input() estimatedIncidentCost: number = 0;
  @Input() vehiclesRented: number = 0;
}
