import { IncidentResource, IncidentsResponse } from './incident-response';
import { Incident } from '../domain/model/incident.entity';
import { BaseAssembler } from '../../shared/infrastructure/base-assembler';

/**
 * @summary Maps incident domain entities to and from infrastructure contracts.
 * @author u20241a195 - Sofia Diaz Yurivilca
 */
export class IncidentAssembler implements BaseAssembler<
  Incident,
  IncidentResource,
  IncidentsResponse
> {
  toEntitiesFromResponse(response: IncidentsResponse): Incident[] {
    return response.incidents.map((r) => this.toEntityFromResource(r));
  }

  toEntityFromResource(resource: IncidentResource): Incident {
    return {
      id: resource.id,
      vehicleId: resource.vehicleId,
      rentalId: resource.rentalId,
      incidentType: resource.incidentType as Incident['incidentType'],
      registeredAt: resource.registeredAt,
      estimatedRepairCost: resource.estimatedRepairCost,
      priority: resource.priority as Incident['priority'],
    };
  }

  toResourceFromEntity(entity: Incident): IncidentResource {
    return {
      id: entity.id,
      vehicleId: entity.vehicleId,
      rentalId: entity.rentalId,
      incidentType: entity.incidentType,
      registeredAt: entity.registeredAt,
      estimatedRepairCost: entity.estimatedRepairCost,
      priority: entity.priority,
    };
  }
}
