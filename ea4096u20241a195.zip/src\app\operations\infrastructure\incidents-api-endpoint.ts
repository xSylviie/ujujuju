import { BaseApiEndpoint } from '../../shared/infrastructure/base-api-endpoint';
import { Incident } from '../domain/model/incident.entity';
import { IncidentResource, IncidentsResponse } from './incident-response';
import { IncidentAssembler } from './incident-assembler';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../../environments/environment';

/**
 * @summary Infrastructure endpoint client for incident CRUD integration.
 * @author u20241a195 - Sofia Diaz Yurivilca
 */
export class IncidentsApiEndpoint extends BaseApiEndpoint<
  Incident,
  IncidentResource,
  IncidentsResponse,
  IncidentAssembler
> {
  constructor(http: HttpClient) {
    super(http, `${environment.serverBasePath}/incidents`, new IncidentAssembler());
  }
}
