import { computed, Injectable, signal } from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { MastersApi } from '../infrastructure/masters-api';
import { Vehicle } from '../domain/model/vehicle.entity';
import { Incident } from '../../operations/domain/model/incident.entity';

/**
 * @summary Application-layer store that orchestrates Masters use cases (vehicles).
 * @author u20241a195 - Sofia Diaz Yurivilca
 */
@Injectable({ providedIn: 'root' })
export class MastersStore {
  private readonly vehiclesSignal = signal<Vehicle[]>([]);
  readonly vehicles = this.vehiclesSignal.asReadonly();

  private readonly loadingSignal = signal<boolean>(false);
  readonly loading = this.loadingSignal.asReadonly();

  private readonly errorSignal = signal<string | null>(null);
  readonly error = this.errorSignal.asReadonly();

  readonly vehicleTypes = computed(() => {
    const types = [...new Set(this.vehiclesSignal().map((v) => v.vehicleType))];
    return (['ECONOMY', 'SUV', 'LUXURY'] as const).filter((t) => types.includes(t));
  });

  constructor(private mastersApi: MastersApi) {
    this.loadVehicles();
  }

  /** Returns vehicles filtered by type. */
  getVehiclesByType(type: string): Vehicle[] {
    return this.vehiclesSignal().filter((v) => v.vehicleType === type);
  }

  /** Daily Revenue Potential: sum of dailyRate for RENTED vehicles of a given type. */
  getDailyRevenuePotential(type: string): number {
    return this.getVehiclesByType(type)
      .filter((v) => v.status === 'RENTED')
      .reduce((sum, v) => sum + v.dailyRate, 0);
  }

  /** Vehicles Rented count for a given type. */
  getRentedCount(type: string): number {
    return this.getVehiclesByType(type).filter((v) => v.status === 'RENTED').length;
  }

  /**
   * Estimated Incident Cost: sum of estimatedRepairCost * priority factor
   * for all incidents belonging to vehicles of the given type.
   * HIGH = 2.0, NORMAL = 1.0. Rounded to 2 decimals.
   */
  getEstimatedIncidentCost(type: string, incidents: Incident[]): number {
    const vehicleIds = this.getVehiclesByType(type).map((v) => v.id);
    const total = incidents
      .filter((i) => vehicleIds.includes(i.vehicleId))
      .reduce((sum, i) => {
        const factor = i.priority === 'HIGH' ? 2.0 : 1.0;
        return sum + i.estimatedRepairCost * factor;
      }, 0);
    return Math.round(total * 100) / 100;
  }

  /** Retrieves a vehicle by its identifier. */
  getVehicleById(id: number): Vehicle | undefined {
    return this.vehiclesSignal().find((v) => v.id === id);
  }

  private loadVehicles(): void {
    this.mastersApi
      .getVehicles()
      .pipe(takeUntilDestroyed())
      .subscribe({
        next: (vehicles) => this.vehiclesSignal.set(vehicles),
        error: () => this.errorSignal.set('Failed to load vehicles'),
      });
  }
}
