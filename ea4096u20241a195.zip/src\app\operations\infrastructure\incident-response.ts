import { BaseResource, BaseResponse } from '../../shared/infrastructure/base-response';

/**
 * @summary Infrastructure resource contract representing an incident record.
 * @author u20241a195 - Sofia Diaz Yurivilca
 */
export interface IncidentResource extends BaseResource {
  id: number;
  vehicleId: number;
  rentalId: number | null;
  incidentType: string;
  registeredAt: string;
  estimatedRepairCost: number;
  priority: string;
}

/**
 * @summary Infrastructure response envelope for incident collection queries.
 * @author u20241a195 - Sofia Diaz Yurivilca
 */
export interface IncidentsResponse extends BaseResponse {
  incidents: IncidentResource[];
}
