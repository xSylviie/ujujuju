import { BaseResource, BaseResponse } from '../../shared/infrastructure/base-response';

/**
 * @summary Infrastructure resource contract representing a rental record.
 * @author u20241a195 - Sofia Diaz Yurivilca
 */
export interface RentalResource extends BaseResource {
  id: number;
  vehicleId: number;
  clientId: number;
  startDate: string;
  endDate: string;
  durationDays: number;
  totalCost: number;
  status: string;
}

/**
 * @summary Infrastructure response envelope for rental collection queries.
 * @author u20241a195 - Sofia Diaz Yurivilca
 */
export interface RentalsResponse extends BaseResponse {
  rentals: RentalResource[];
}
