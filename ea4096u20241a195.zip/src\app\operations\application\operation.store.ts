import { computed, Injectable, signal } from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { retry } from 'rxjs';
import { OperationsApi } from '../infrastructure/operations-api';
import { Rental } from '../domain/model/rental.entity';
import { Incident } from '../domain/model/incident.entity';

/**
 * @summary Application-layer store that orchestrates Operations use cases (rentals and incidents).
 * @author u20241a195 - Sofia Diaz Yurivilca
 */
@Injectable({ providedIn: 'root' })
export class OperationsStore {
  private readonly rentalsSignal = signal<Rental[]>([]);
  readonly rentals = this.rentalsSignal.asReadonly();

  private readonly incidentsSignal = signal<Incident[]>([]);
  readonly incidents = this.incidentsSignal.asReadonly();

  private readonly loadingSignal = signal<boolean>(false);
  readonly loading = this.loadingSignal.asReadonly();

  private readonly errorSignal = signal<string | null>(null);
  readonly error = this.errorSignal.asReadonly();

  /** Most recent incident with priority NORMAL. */
  readonly nextUrgentIncident = computed(() => {
    const normalIncidents = this.incidentsSignal()
      .filter((i) => i.priority === 'NORMAL')
      .sort((a, b) => new Date(b.registeredAt).getTime() - new Date(a.registeredAt).getTime());
    return normalIncidents[0] ?? null;
  });

  constructor(private operationsApi: OperationsApi) {
    this.loadRentals();
    this.loadIncidents();
  }

  /** Creates a new rental and its associated CLEANING incident. */
  createRentalWithIncident(rental: Rental): Promise<void> {
    return new Promise((resolve, reject) => {
      this.loadingSignal.set(true);
      this.operationsApi
        .createRental(rental)
        .pipe(retry(1))
        .subscribe({
          next: (createdRental) => {
            this.rentalsSignal.update((list) => [...list, createdRental]);
            const incident: Incident = {
              id: 0,
              vehicleId: rental.vehicleId,
              rentalId: createdRental.id,
              incidentType: 'CLEANING',
              registeredAt: new Date().toISOString(),
              estimatedRepairCost: 50.0,
              priority: 'NORMAL',
            };
            this.operationsApi
              .createIncident(incident)
              .pipe(retry(1))
              .subscribe({
                next: (createdIncident) => {
                  this.incidentsSignal.update((list) => [...list, createdIncident]);
                  this.loadingSignal.set(false);
                  resolve();
                },
                error: (err) => {
                  this.errorSignal.set('Failed to create cleaning incident');
                  this.loadingSignal.set(false);
                  reject(err);
                },
              });
          },
          error: (err) => {
            this.errorSignal.set('Failed to create rental');
            this.loadingSignal.set(false);
            reject(err);
          },
        });
    });
  }

  /** Checks if a vehicle already has an active rental. */
  hasActiveRental(vehicleId: number): boolean {
    return this.rentalsSignal().some((r) => r.vehicleId === vehicleId && r.status === 'ACTIVE');
  }

  private loadRentals(): void {
    this.operationsApi
      .getRentals()
      .pipe(takeUntilDestroyed())
      .subscribe({
        next: (rentals) => this.rentalsSignal.set(rentals),
        error: (err) => this.errorSignal.set('Failed to load rentals'),
      });
  }

  private loadIncidents(): void {
    this.operationsApi
      .getIncidents()
      .pipe(takeUntilDestroyed())
      .subscribe({
        next: (incidents) => this.incidentsSignal.set(incidents),
        error: (err) => this.errorSignal.set('Failed to load incidents'),
      });
  }
}
