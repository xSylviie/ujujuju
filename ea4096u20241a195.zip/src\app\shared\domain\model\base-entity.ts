/**
 * @summary Base contract for domain entities across bounded contexts.
 * @author u20241a195 - Sofia Diaz Yurivilca
 */
export interface BaseEntity {
  id: number;
}
