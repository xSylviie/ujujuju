import { BaseApiEndpoint } from '../../shared/infrastructure/base-api-endpoint';
import { Rental } from '../domain/model/rental.entity';
import { RentalResource, RentalsResponse } from './rental-response';
import { RentalAssembler } from './rental-assembler';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../../environments/environment';

/**
 * @summary Infrastructure endpoint client for rental CRUD integration.
 * @author u20241a195 - Sofia Diaz Yurivilca
 */
export class RentalsApiEndpoint extends BaseApiEndpoint<
  Rental,
  RentalResource,
  RentalsResponse,
  RentalAssembler
> {
  constructor(http: HttpClient) {
    super(http, `${environment.serverBasePath}/rentals`, new RentalAssembler());
  }
}
