import { Routes } from '@angular/router';

/**
 * @summary Child routes for the Operations bounded context.
 * @author  u20241a195 - Sofia Diaz Yurivilca
 */
export const operationsRoutes: Routes = [
  {
    path: 'rentals/new',
    loadComponent: () => import('./views/new-rental/new-rental').then((m) => m.NewRental),
    title: 'Enterprise Fleet Manager - New Rental',
  },
];
