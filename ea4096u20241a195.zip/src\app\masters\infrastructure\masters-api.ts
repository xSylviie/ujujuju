import { Injectable } from '@angular/core';
import { BaseApi } from '../../shared/infrastructure/base-api';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Vehicle } from '../domain/model/vehicle.entity';
import { VehiclesApiEndpoint } from './vehicles-api-endpoint';

/**
 * @summary Infrastructure facade exposing Masters bounded-context endpoint operations.
 * @author u20241a195 - Sofia Diaz Yurivilca
 */
@Injectable({ providedIn: 'root' })
export class MastersApi extends BaseApi {
  private readonly vehiclesEndpoint: VehiclesApiEndpoint;

  constructor(http: HttpClient) {
    super();
    this.vehiclesEndpoint = new VehiclesApiEndpoint(http);
  }

  getVehicles(): Observable<Vehicle[]> {
    return this.vehiclesEndpoint.getAll();
  }
}
