import { BaseEntity } from '../../../shared/domain/model/base-entity';

/**
 * @summary Domain entity representing a vehicle rental contract.
 * @author u20241a195 - Sofia Diaz Yurivilca
 */
export interface Rental extends BaseEntity {
  id: number;
  vehicleId: number;
  clientId: number;
  startDate: string;
  endDate: string;
  durationDays: number;
  totalCost: number;
  status: 'ACTIVE' | 'COMPLETED' | 'CANCELED';
}
