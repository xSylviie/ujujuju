/**
 * @summary Marker contract for HTTP response envelopes in the infrastructure layer.
 * @author u20241a195 - Sofia Diaz Yurivilca
 */
export interface BaseResponse {}

/**
 * @summary Base shape for infrastructure resources exchanged with remote APIs.
 * @author u20241a195 - Sofia Diaz Yurivilca
 */
export interface BaseResource {
  id: number;
}
