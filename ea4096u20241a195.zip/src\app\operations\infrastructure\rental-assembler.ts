import { RentalResource, RentalsResponse } from './rental-response';
import { Rental } from '../domain/model/rental.entity';
import { BaseAssembler } from '../../shared/infrastructure/base-assembler';

/**
 * @summary Maps rental domain entities to and from infrastructure contracts.
 * @author u20241a195 - Sofia Diaz Yurivilca
 */
export class RentalAssembler implements BaseAssembler<Rental, RentalResource, RentalsResponse> {
  toEntitiesFromResponse(response: RentalsResponse): Rental[] {
    return response.rentals.map((r) => this.toEntityFromResource(r));
  }

  toEntityFromResource(resource: RentalResource): Rental {
    return {
      id: resource.id,
      vehicleId: resource.vehicleId,
      clientId: resource.clientId,
      startDate: resource.startDate,
      endDate: resource.endDate,
      durationDays: resource.durationDays,
      totalCost: resource.totalCost,
      status: resource.status as Rental['status'],
    };
  }

  toResourceFromEntity(entity: Rental): RentalResource {
    return {
      id: entity.id,
      vehicleId: entity.vehicleId,
      clientId: entity.clientId,
      startDate: entity.startDate,
      endDate: entity.endDate,
      durationDays: entity.durationDays,
      totalCost: entity.totalCost,
      status: entity.status,
    };
  }
}
