import { Component, computed, inject } from '@angular/core';
import { DatePipe, CurrencyPipe } from '@angular/common';
import { MatGridListModule } from '@angular/material/grid-list';
import { MatCardModule } from '@angular/material/card';
import { TranslatePipe } from '@ngx-translate/core';
import { MastersStore } from '../../../application/masters.store';
import { OperationsStore } from '../../../../operations/application/operation.store';
import { VehicleTypeStats } from '../../components/vehicle-type-stats/vehicle-type-stats';

/**
 * @summary Home dashboard presenting fleet analytics and the next urgent incident.
 * @author u20241a195 - Sofia Diaz Yurivilca
 */
@Component({
  selector: 'app-home',
  standalone: true,
  imports: [
    MatGridListModule,
    MatCardModule,
    TranslatePipe,
    DatePipe,
    CurrencyPipe,
    VehicleTypeStats,
  ],
  templateUrl: './home.html',
  styleUrl: './home.css',
})
export class Home {
  private readonly mastersStore = inject(MastersStore);
  private readonly operationsStore = inject(OperationsStore);

  protected readonly vehicleTypes = this.mastersStore.vehicleTypes;
  protected readonly nextUrgentIncident = this.operationsStore.nextUrgentIncident;
  protected readonly loading = computed(
    () => this.mastersStore.loading() || this.operationsStore.loading(),
  );

  /** Builds per-type analytics inputs for Vehicle Type Stats cards. */
  protected readonly typeStats = computed(() =>
    this.vehicleTypes().map((type) => ({
      vehicleType: type,
      dailyRevenuePotential: this.mastersStore.getDailyRevenuePotential(type),
      estimatedIncidentCost: this.mastersStore.getEstimatedIncidentCost(
        type,
        this.operationsStore.incidents(),
      ),
      vehiclesRented: this.mastersStore.getRentedCount(type),
    })),
  );
}
