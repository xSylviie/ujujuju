/**
 * @summary Marker base type for infrastructure API facades.
 * @author  u20241a195 - Sofia Diaz Yurivilca
 */
export abstract class BaseApi {}
