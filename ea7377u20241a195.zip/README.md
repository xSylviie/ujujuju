# Enterprise Fleet Manager

## Description

Enterprise Fleet Manager is a web application for managing the Enterprise Rent-A-Car vehicle fleet. It provides real-time analytics on fleet utilization, rental operations, and incident tracking.

### Key Features

- **Fleet Utilization Analytics**: Displays Daily Revenue Potential, Estimated Incident Cost, and Vehicles Rented for each vehicle type (ECONOMY, SUV, LUXURY).
- **Next Urgent Incident**: Shows the most recent incident with NORMAL priority.
- **New Rental**: Form to create rental contracts with automatic CLEANING incident generation.
- **Internationalization**: Full English and Spanish support.

## Author

**u20241a195 - Sofia Diaz Yurivilca** — UPC, Ingeniería de Software, 1ASI0729, 202520, NRC 7377

## Technology Stack

- Angular 21 (Standalone Components)
- Angular Material (UI Components)
- @ngx-translate/core (i18n)
- Angular Signals (State Management)
- json-server 0.17.4 (Fake REST API)
- TypeScript

## Project Structure

Domain-Driven Architecture with bounded contexts:
- `shared/`: Common elements (layout, page-not-found, base infrastructure patterns)
- `masters/`: Vehicle management (Fleet Utilization Analytics, Home view)
- `operations/`: Rentals and incidents (New Rental form)

## Getting Started

### Prerequisites
- Node.js 18+
- npm

### Install dependencies
```bash
npm install
```

### Start the fake API backend
```bash
cd server
npx json-server --watch db.json
```

### Start the application
```bash
ng serve
```

Open [http://localhost:4200](http://localhost:4200) in your browser.

## Routes

| Route | Description |
|-------|-------------|
| `/` | Redirects to `/home` |
| `/home` | Fleet analytics dashboard |
| `/operations/rentals/new` | Create new rental |
| `/**` | 404 Page Not Found |
